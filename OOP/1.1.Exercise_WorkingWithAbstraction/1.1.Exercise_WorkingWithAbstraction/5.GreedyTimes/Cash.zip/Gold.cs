﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _5.GreedyTimes
{
    public class Gold : Item
    {
        public Gold(string key, long value) 
            : base(key, value)
        {
        }
    }
}
