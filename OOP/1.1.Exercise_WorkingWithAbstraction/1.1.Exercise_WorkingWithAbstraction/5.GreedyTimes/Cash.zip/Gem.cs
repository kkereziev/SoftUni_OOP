﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _5.GreedyTimes
{
    public class Gem : Item
    {
        public Gem(string key, long value) 
            : base(key, value)
        {
        }
    }
}
