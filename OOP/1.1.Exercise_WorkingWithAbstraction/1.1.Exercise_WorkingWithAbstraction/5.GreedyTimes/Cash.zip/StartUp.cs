﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _5.GreedyTimes
{
    class StartUp
    {
        static void Main(string[] args)
        {
            RunProgram.Run();
        }
    }
}
