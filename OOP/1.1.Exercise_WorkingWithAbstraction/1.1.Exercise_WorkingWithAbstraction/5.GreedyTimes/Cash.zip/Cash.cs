﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _5.GreedyTimes
{
    public class Cash : Item
    {
        public Cash(string key, long value) 
            : base(key, value)
        {
        }
    }
}
